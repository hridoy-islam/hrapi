

export const SupervisionSearchableFields = [];
