
  
  export const CompanyReportSearchableFields = ["name"];
  