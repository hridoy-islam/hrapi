
  
  export const RotaSearchableFields = ["name"];
  