

export const DisciplinarySearchableFields = [];
