
  
  export const CompanyBranchSearchableFields = ["branchName"];
  