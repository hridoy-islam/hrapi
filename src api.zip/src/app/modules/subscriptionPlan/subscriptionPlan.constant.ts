
  
  export const SubscriptionPlanSearchableFields = ["name"];
  