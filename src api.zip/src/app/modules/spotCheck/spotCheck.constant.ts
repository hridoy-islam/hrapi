

export const SpotCheckSearchableFields = [];
