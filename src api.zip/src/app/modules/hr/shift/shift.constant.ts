
  
  export const ShiftSearchableFields = ["name"];
  