
  
  export const EmployeeRateSearchableFields = ["name"];
  