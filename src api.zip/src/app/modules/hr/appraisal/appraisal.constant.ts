
  
  export const AppraisalSearchableFields = [];
  