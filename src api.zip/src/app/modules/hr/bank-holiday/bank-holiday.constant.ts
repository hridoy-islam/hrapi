
  
  export const BankHolidaySearchableFields = ["title"];
  