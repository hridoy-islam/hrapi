
  
  export const EmployeeTrainingSearchableFields = [];
  