

export const InductionSearchableFields = [];
