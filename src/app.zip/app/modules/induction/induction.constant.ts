

export const InductionSearchableFields = [];
