

export const SpotCheckSearchableFields = [];
