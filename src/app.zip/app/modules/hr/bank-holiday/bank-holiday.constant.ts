
  
  export const BankHolidaySearchableFields = ["title"];
  