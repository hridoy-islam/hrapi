
  
  export const EmployeeTrainingSearchableFields = [];
  