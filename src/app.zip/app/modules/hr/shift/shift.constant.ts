
  
  export const ShiftSearchableFields = ["name"];
  