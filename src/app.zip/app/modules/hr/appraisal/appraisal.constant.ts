
  
  export const AppraisalSearchableFields = [];
  