
  
  export const EmployeeRateSearchableFields = ["name"];
  