

export const DisciplinarySearchableFields = [];
