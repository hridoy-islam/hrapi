
  
  export const RotaSearchableFields = ["name"];
  