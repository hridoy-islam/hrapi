
  
  export const CompanyBranchSearchableFields = ["branchName"];
  