
  
  export const SubscriptionPlanSearchableFields = ["name"];
  