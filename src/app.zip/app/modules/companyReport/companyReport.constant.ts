
  
  export const CompanyReportSearchableFields = ["name"];
  