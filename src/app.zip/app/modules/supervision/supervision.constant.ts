

export const SupervisionSearchableFields = [];
